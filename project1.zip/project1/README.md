#READ ME for Anton Domratchev's bangShell

##Following are the commands required for compilation
```
$:gcc bangShell.c -o bangShell
```

##Following are enviroments for compiled version
```
Ubuntu 64 bit 12.10
```
